export { default } from './lab';
